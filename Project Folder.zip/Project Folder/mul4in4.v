module mul4in4(
	input [3:0] a,b,
	output[7:0] p

);


wire [3:0] b0,b1,b2,b3;

assign b0 = {4{b[0]}} & a[3:0]; 
assign b1 = {4{b[1]}} & a[3:0]; 
assign b2 = {4{b[2]}} & a[3:0]; 
assign b3 = {4{b[3]}} & a[3:0]; 


wire [3:0] sum1, sum2, sum3;
wire cout1, cout2, cout3;

// Four bit adder 1
four_bit_adder FBA0({1'b0,b0[3:1]},{b1[3:0]},1'b0,sum1,cout1);

// Four bit adder 2
four_bit_adder FBA1({cout1,sum1[3:1]},{b2[3:0]},1'b0,sum2,cout2);

// Four bit adder 3
four_bit_adder FBA2({cout2,sum2[3:1]},{b3[3:0]},1'b0,sum3,cout3);


assign p[0]= b0[0];
assign p[1]= sum1[0];
assign p[2]= sum2[0];
assign p[6:3]= sum3[3:0];
assign p[7]= cout3;

endmodule 