module thirteen_bit_adder(
	input [12:0]A,
	input [12:0]B,
	input Cin,
	
	output [12:0]S,
	output cout
	
);


	wire c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12;

	full_adder FA0(A[0], B[0],Cin, S[0], c1);
	full_adder FA1(A[1], B[1],c1, S[1], c2);
	full_adder FA2(A[2], B[2],c2, S[2], c3);
	full_adder FA3(A[3], B[3],c3, S[3], c4);
	full_adder FA4(A[4], B[4],c4, S[4], c5);
	full_adder FA5(A[5], B[5],c5, S[5], c6);
	full_adder FA6(A[6], B[6],c6, S[6], c7);
	full_adder FA7(A[7], B[7],c7, S[7], c8);
	full_adder FA8(A[8], B[8],c8, S[8], c9);
	full_adder FA9(A[9], B[9],c9, S[9], c10);
	full_adder FA10(A[10], B[10],c10, S[10], c11);
	full_adder FA11(A[11], B[11],c11, S[11], c12);
	full_adder FA12(A[12], B[12],c12, S[12], cout);


endmodule 